﻿/////////////////////////////////////////////////////////////
// App.xam1.cs - Bar Chart Demo in WPF                     //
//                                                         //
// Jim Fawcett, CSE775 - Distributed Objects, Spring 2009  //
/////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace BarChart
{
  /// <summary>
  /// Interaction logic for App.xaml
  /// </summary>
  public partial class App : Application
  {
  }
}
