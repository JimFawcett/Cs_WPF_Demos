﻿/*
<!-- ...................................................... -->
<!-- App.xaml.cs - Wpf_Triggers                             -->
<!--               Demonstrates styles and triggers         -->
<!--                                                        -->
<!-- Jim Fawcett, CSE775 - Distributed Objects, Spring 2009 -->
<!-- ...................................................... -->
*/
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace Wpf_Triggers
{
  public partial class App : Application
  {
  }
}
