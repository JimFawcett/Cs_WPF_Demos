﻿/*
<!-- ...................................................... -->
<!-- App.xaml - Wpf_AttachedProperties                      -->
<!--            Demonstrates WPF Property System            -->
<!--                                                        -->
<!-- Jim Fawcett, CSE775 - Distributed Objects, Spring 2009 -->
<!-- ...................................................... -->
*/
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace Wpf_AttachedProperties
{
  public partial class App : Application
  {
  }
}
